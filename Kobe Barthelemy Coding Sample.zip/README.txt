Kobe Barthelemy Coding Sample

The purpose of this project was to highlight my skills and capabilities in the statistical software RStudio.
The dataset, present through RStudio, was acquired from the Federal Reserve Bank of St. Louis.
To see the results of the code, run (ctrl+enter) the concluding lines of each section of code.
Thank you for taking the time to analyze my coding sample; I hope you enjoy it.