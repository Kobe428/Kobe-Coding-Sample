library(tidyverse)
library(dplyr)
library(ggplot2)
library(lubridate)

new_dates <- economics %>% 
  filter(date >= as.Date("2000-01-01") & date <= as.Date("2015-12-31")) %>% 
  select(date, pce, pop, unemploy)

grouped_data <- group_by(new_dates, year = lubridate::year(date))

aggregated_data <- summarise(grouped_data, average_PCE = mean(pce), 
                             average_POP = mean(pop), 
                             average_UNEMPLOY = mean(unemploy))

PCE_data <- aggregated_data %>% 
  select(year, average_PCE) %>% 
  view
  
PCE_data %>% 
  ggplot(aes(x = year, y = average_PCE, fill = "MyColor")) +
  geom_col(color = "red", width = .7, alpha = 1) +
  scale_fill_manual(values = "red") +
  labs(title = "Average Personal Consumption Expenditures From 2000 to 2015",
       x = "Year",
       y = "Average Personal Consumption Expenditures (billions of dollars, in thousands)")
# Average personal consumption, for the most part, steadily increased throughout the years listed, despite the two recessions.

POP_data <- aggregated_data %>% 
  select(year, average_POP) %>% 
  view

POP_data %>% 
  ggplot(aes(x = year, y = average_POP, fill = "MyColor")) +
  geom_col(color = "blue", width = .7, alpha = 1) + 
  scale_fill_manual(values = "blue") +
  labs(title = "Average Total Population From 2000 to 2015",
       x = "Year",
       y = "Average Total Population (millions, in thousands)") +
  coord_cartesian(ylim = c(2.7e5, 3.3e5))
# Average total population steadily increased throughout the years listed.

UNEMPLOY_data <- aggregated_data %>% 
  select(year, average_UNEMPLOY) %>% 
  view

UNEMPLOY_data %>% 
  ggplot(aes(x = year, y = average_UNEMPLOY, fill = "MyColor")) +
  geom_col(color = "green", width = .7, alpha = 1) +
  scale_fill_manual(values = "green") +
  labs(title = "Average Unemployed Population From 2000 to 2015",
       x = "Year",
       y = "Average Unemployed Population (millions, in thousands)")
# Average unemployment clearly rose during the 2001 and 2008/2009 recessions.